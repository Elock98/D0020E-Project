"compose-ca.yaml is used to create CA's
compose-test-net.yaml is used to create nodes and cli"
